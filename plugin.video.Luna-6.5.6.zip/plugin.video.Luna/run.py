import logging
def get_tokens_with_headers(url,headers={},get_url=False):
    import cfscrape2,requests
    s=cfscrape2.CloudflareScraper()
    
    import requests                                                                    
                                                             
                                                                                       
                                            
    
    headers2={                                                                          
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0',                                                              
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',   
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',                                  
        'DNT': '1',                                                                    
        'Connection': 'keep-alive',                                                    
        'Upgrade-Insecure-Requests': '1',}
    if 'Referer' in headers:
        headers2['Referer']=headers['Referer']
    
    s.headers.update(headers2)
    r=s.get(url)
    my_cookies = requests.utils.dict_from_cookiejar(s.cookies)
    result=r.content

    if get_url:
        
        result= r.url
    
    my_cookies = requests.utils.dict_from_cookiejar(s.cookies)

    end_c=[]
    end_c.append(my_cookies)
    end_c.append(headers2)
   
    return result,end_c
def run_dds (O00OOOO0000O00O0O ):#line:224
    logging.warning('Run DDS')
    O00OOOO0000O00O0O =O00OOOO0000O00O0O .replace ('99999****','')#line:225
    import base64
    import zlib
    if '$$$$$' in O00OOOO0000O00O0O:
        O00OOOO0000O00O0O =O00OOOO0000O00O0O .split ("$$$$$")[0]#line:236
    data = O00OOOO0000O00O0O

    json_str = zlib.decompress(base64.b64decode(data), 16 + zlib.MAX_WBITS).decode('utf-8')
    try:
        O00O00OO00O0O00OO = zlib.decompress(base64.b64decode(json_str), 16 + zlib.MAX_WBITS).decode('utf-8')
    except:
        O00O00OO00O0O00OO=json_str
    return O00O00OO00O0O00OO #line:253
    O0OO00OOOO0OOO000 =O00O00OO00O0O00OO .split ("$$$$$")#line:236
    OOOO0OO0O00O00O0O =str (O0OO00OOOO0OOO000 [1 ]).strip ().encode ('base64')#line:238
    O00OO0O0OOOO00O0O =str (Addon .getAddonInfo ("name")).strip ().encode ('base64')#line:239
    if OOOO0OO0O00O00O0O !=O00OO0O0OOOO00O0O :#line:242
        xbmcgui .Dialog ().ok ('15zXkCDXmdek15Q='.decode ('base64 '),"15TXp9eZ16nXldeoINec15Ag16nXmdeZ15og15zXlNeo15fXkdeUINeW15Ug16TXotedINeU15HXkNeUINeq15HXp9epINeo16nXldeqLg==".decode ('base64 '))#line:243
        return ''#line:244
    logging.warning('d:'+O00OO0O0OOOO00O0O)
    OO00OOO0OOOO00000 =StringIO .StringIO ()#line:228
    OO00OOO0OOOO00000 .write (O0OO00OOOO0OOO000 [0 ] .decode ('base64'))#line:229
    OO00OOO0OOOO00000 .seek (0 )#line:234
    O00O00OO00O0O00OO =gzip .GzipFile (fileobj =OO00OOO0OOOO00000 ,mode ='rb').read ()#line:252
    return O00O00OO00O0O00OO #line:253